-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_skljhhclgzhycmnsyskgolnzugwywqkzulyp` (`ownerId`),
  CONSTRAINT `fk_deetyoryvrcchnfpattgyarbqassebhkscqk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_skljhhclgzhycmnsyskgolnzugwywqkzulyp` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `pluginId` int(11) DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT 1,
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_riekqqutipydveknkdphwbkjcbahalfhpems` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_rdaiykmdkwtvymizfisbzbwjbwvteutsnvyv` (`dateRead`),
  KEY `fk_ybgzvltrogideudvxhhqkebwkylkazhpztsw` (`pluginId`),
  CONSTRAINT `fk_rppeduikcwwcxskpgvsnjbhxgdohkpaveetk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ybgzvltrogideudvxhhqkebwkylkazhpztsw` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` int(11) NOT NULL,
  `volumeId` int(11) NOT NULL,
  `uri` text DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT 0,
  `recordId` int(11) DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT 0,
  `inProgress` tinyint(1) DEFAULT 0,
  `completed` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rdgcjjzlyyosdkoyckqtgjknwbmcihokbeyc` (`sessionId`,`volumeId`),
  KEY `idx_nbrhrgyxwelonebvmndzhggkpividmwbawty` (`volumeId`),
  CONSTRAINT `fk_febauuianghskegmbiyaueiovgwtoukryvgw` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_swcajyhvqgelqgfezrflgjkmodbpwqixwmmd` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text DEFAULT NULL,
  `totalEntries` int(11) DEFAULT NULL,
  `processedEntries` int(11) NOT NULL DEFAULT 0,
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT 0,
  `isCli` tinyint(1) DEFAULT 0,
  `actionRequired` tinyint(1) DEFAULT 0,
  `processIfRootEmpty` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_amhggkztgfftfsvirswaxkqxgzelsxvxvnrm` (`filename`,`folderId`),
  KEY `idx_kwysdmrvmjbentjyisbavsgayuaonakdxkta` (`folderId`),
  KEY `idx_onbqrguajfrkxarezxwzkbovezihquwcwumz` (`volumeId`),
  KEY `fk_sotqszezpotnswlbdgrxfnfaeuozbglvyfaz` (`uploaderId`),
  CONSTRAINT `fk_lmatmoydmqysmtklwhcawftyzfucbptfdpdt` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sotqszezpotnswlbdgrxfnfaeuozbglvyfaz` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_trpbxuvrwjhzyyruubekpnqdpqmowammtgsr` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wsytnsufemphguewjchduwxeewyumcgcsryo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_coibhyoaoldnnradiamauwqapjxemqtexgsp` (`groupId`),
  KEY `fk_zcjriudbzuyxxnnogbzpahwyxgjdooldmnbo` (`parentId`),
  CONSTRAINT `fk_tegtkcojxftyrceqjpkcmpvmxrhzcadbrcza` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vnlvaymwptqesitqwbxgvvcxrxrwizvzojnb` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zcjriudbzuyxxnnogbzpahwyxgjdooldmnbo` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cjvsseguoybgrgtrotywfvevgirlgwydnspq` (`name`),
  KEY `idx_hibgjitwcinelnaeecwxwittdymjdfljbfwk` (`handle`),
  KEY `idx_dwnlerynsuwhgdzzavupdrnqqeoedrbzooaf` (`structureId`),
  KEY `idx_wdvrpfzbsmvfoyisutmyihwqffhmkquiruae` (`fieldLayoutId`),
  KEY `idx_jdlzjowdhoylfymjpcltiztofdsuurnjhimo` (`dateDeleted`),
  CONSTRAINT `fk_bwqnnpmeoeokqhzklbclyuflxeptcqcxmiyo` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_djtqmmwznqckscazmqfmcnoptlgnilsnyvzr` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yjuwsifdgvwbeskvtarnvgghqovzrngdokdn` (`groupId`,`siteId`),
  KEY `idx_xwogacnrdvqgkswfbayphbagjuiqpkjubzit` (`siteId`),
  CONSTRAINT `fk_fogaupouqglzpixycepztiblokyyrdfhuraj` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_yuorbkzwrddwicnojybnemiwsvhigfxzamcw` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_nnidvvoucvahqldgaybyxpvlmqqeuuazamax` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_fipllwrpxqaigvukvhfcbcpohasmbqidofza` (`siteId`),
  KEY `fk_vkpysiuhypntvmyihxvizyunmeykapqtxwkw` (`userId`),
  CONSTRAINT `fk_bihebcesiuhfsjcaypjkloyceyqfzqscsfff` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fipllwrpxqaigvukvhfcbcpohasmbqidofza` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vkpysiuhypntvmyihxvizyunmeykapqtxwkw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES
(2,1,'postDate','2024-09-09 15:05:37',0,1),
(2,1,'slug','2024-09-09 15:05:29',0,1),
(2,1,'title','2024-09-09 15:05:29',0,1),
(2,1,'uri','2024-09-09 15:05:29',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_yddsmwzlqocyepybedwqgultmspymkgresbs` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_eruanicvunjitehpmysyldsosvewglfbwyqp` (`siteId`),
  KEY `fk_gvyxfmvyiafbgewskzprpvtwznsufcgzgmos` (`fieldId`),
  KEY `fk_scqmgjsfostydowrurulpgvgybnyafrtaogp` (`userId`),
  CONSTRAINT `fk_eruanicvunjitehpmysyldsosvewglfbwyqp` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_gvyxfmvyiafbgewskzprpvtwznsufcgzgmos` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_scqmgjsfostydowrurulpgvgybnyafrtaogp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_xcsyzqkmbbcrwubnnrqvpsekijnvyipsuhzu` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES
(2,1,1,'2024-09-09 15:08:49',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_otemigihxukgkucftlkrwvehtutcewhyvpch` (`elementId`,`siteId`),
  KEY `idx_xmefmahjnnlbhfqbumncdfkhcyarirgzyvdl` (`siteId`),
  KEY `idx_lhwrzdhafhzowornddlizaixlczcuzcbbinr` (`title`),
  CONSTRAINT `fk_gauknulzdbltrygphgaltzzvhyvqaxwxgdkt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jdtinybytqmbhdmmlaepdwumpsamwgvugqox` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES
(1,1,1,NULL,'2024-09-09 14:58:08','2024-09-09 14:58:08','a7e7cb21-ffd7-4c6c-a982-654224c896be'),
(2,2,1,'Test page','2024-09-09 15:05:25','2024-09-09 15:08:49','2ef2f34a-e47b-441c-b85f-d1c02fe263af'),
(3,3,1,NULL,'2024-09-09 15:05:29','2024-09-09 15:05:34','a69a1107-f691-4e58-b9d8-8b4c77290e4a'),
(4,4,1,NULL,'2024-09-09 15:05:30','2024-09-09 15:05:34','3d43ac63-faaa-4095-9f79-4ade944de080'),
(5,5,1,NULL,'2024-09-09 15:05:32','2024-09-09 15:05:34','f93e1234-2137-4bd6-90b5-988eba42b454'),
(6,6,1,NULL,'2024-09-09 15:05:33','2024-09-09 15:05:34','2d7e537d-d2d6-42eb-88fd-9a2913dbcc50'),
(7,7,1,'Test page','2024-09-09 15:05:37','2024-09-09 15:05:37','52f38c3e-fdec-4f33-823b-5b5543ecc7c5'),
(8,8,1,NULL,'2024-09-09 15:05:37','2024-09-09 15:05:37','12963ed6-fb78-44cb-837f-eb2ed9381b7b'),
(9,9,1,NULL,'2024-09-09 15:05:37','2024-09-09 15:05:37','a0d1dd05-f6e7-4889-bf6e-32e938632096'),
(10,10,1,NULL,'2024-09-09 15:05:37','2024-09-09 15:05:37','de06c127-996b-40e9-bd76-a6bc089d69c2'),
(11,11,1,NULL,'2024-09-09 15:05:37','2024-09-09 15:05:37','eb0e9e74-c2e6-4fd0-93b1-8219f22a3f45'),
(13,13,1,'Test page','2024-09-09 15:05:43','2024-09-09 15:05:43','65ca4b6d-3870-4f53-a9e7-89e2ff09f97e'),
(15,15,1,'Test page','2024-09-09 15:08:49','2024-09-09 15:08:49','75b968dd-7c24-474d-a6be-b08ace860abf');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_gnpypuqkjjxjlkxmazjybpsxjtikboybmzli` (`userId`),
  CONSTRAINT `fk_gnpypuqkjjxjlkxmazjybpsxjtikboybmzli` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text DEFAULT NULL,
  `traces` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gqlkxnwztvjfquohpxwaatneyhmlrkvicbfu` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `trackChanges` tinyint(1) NOT NULL DEFAULT 0,
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_tirrfxxmtksqlopxdxjctvoiedbxdcikepzu` (`creatorId`,`provisional`),
  KEY `idx_cfdbirwfdsjqnoeozogqonwjzrzadzogdhvs` (`saved`),
  KEY `fk_stjexhlvmyjkbdhcxkodkstmttuociacorjl` (`canonicalId`),
  CONSTRAINT `fk_nwfiekojlxnurancohiuerzhuturyzbhxxdh` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_stjexhlvmyjkbdhcxkodkstmttuociacorjl` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementactivity` (
  `elementId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `draftId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_ecymmfwuvrlsduliyacxclwcpmhgchblojvm` (`elementId`,`timestamp`,`userId`),
  KEY `fk_ghemrvuvttctobzicplbapalsfqorxrdzkyo` (`userId`),
  KEY `fk_qwlyqujruuebohuwhkqvroxqfkducmtcstdu` (`siteId`),
  KEY `fk_iqvthpuhyrpeebgfufmvmfrxrvperjgzlhza` (`draftId`),
  CONSTRAINT `fk_ghemrvuvttctobzicplbapalsfqorxrdzkyo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iqvthpuhyrpeebgfufmvmfrxrvperjgzlhza` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qwlyqujruuebohuwhkqvroxqfkducmtcstdu` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_toqndzqqxdpsecfcybgnjocjewidnpduozpi` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES
(2,1,1,NULL,'edit','2024-09-09 15:08:48'),
(2,1,1,NULL,'save','2024-09-09 15:08:49');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hpoczifxdqeslkqzqsrbttatjmqdmohongul` (`dateDeleted`),
  KEY `idx_zhmsprxeagqleaeytrcvyambvpdvecenlwvk` (`fieldLayoutId`),
  KEY `idx_brkkmvkhvevuhimrrasvmtfjwxojoiplpgow` (`type`),
  KEY `idx_zpstbrycyiylkpcrflprzokxvlsyjyzdlqec` (`enabled`),
  KEY `idx_xdhfgufyfpuxlidlyefsduxynjvtrjxoykmw` (`canonicalId`),
  KEY `idx_bivsafqvecdydpabxlrwolctaiectzakbcon` (`archived`,`dateCreated`),
  KEY `idx_acunbfvtsxcdymicspxspsidiicvjvoubxjx` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_bcdhlqncejmmzvdsfdecucaomyuhxkypjakj` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_oleidpkwigxaqlkkxnviwyqfquuzvatdqxoo` (`draftId`),
  KEY `fk_dgjdkqjuyesztpzkkeehjcwsgfjzzbbsywdz` (`revisionId`),
  CONSTRAINT `fk_bctenglssevjyoranvbskaxxicvxsmrensxs` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dgjdkqjuyesztpzkkeehjcwsgfjzzbbsywdz` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iydfhnqweowgxkgjgjbngokwenyiyolyzeos` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_oleidpkwigxaqlkkxnviwyqfquuzvatdqxoo` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES
(1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-09-09 14:58:08','2024-09-09 14:58:08',NULL,NULL,'8040e620-0221-4cc7-a3f5-28acbd5f3352'),
(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-09-09 15:05:25','2024-09-09 15:08:49',NULL,NULL,'e0d38637-9b8b-4a03-bfe2-6c55ffc716ee'),
(3,NULL,NULL,NULL,NULL,'benf\\neo\\elements\\Block',1,0,'2024-09-09 15:05:29','2024-09-09 15:05:34',NULL,NULL,'de186d74-e818-4d73-acfd-f34a321966e6'),
(4,NULL,NULL,NULL,NULL,'benf\\neo\\elements\\Block',1,0,'2024-09-09 15:05:30','2024-09-09 15:05:34',NULL,NULL,'503da978-9887-494c-99b1-2b3e4b239386'),
(5,NULL,NULL,NULL,NULL,'benf\\neo\\elements\\Block',1,0,'2024-09-09 15:05:32','2024-09-09 15:05:34',NULL,NULL,'62f22027-7b28-4a6c-9eef-4dbec7276258'),
(6,NULL,NULL,NULL,NULL,'benf\\neo\\elements\\Block',1,0,'2024-09-09 15:05:33','2024-09-09 15:05:34',NULL,NULL,'fe493671-b04d-4c7c-b3d3-8c521a64f914'),
(7,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2024-09-09 15:05:37','2024-09-09 15:05:37',NULL,NULL,'f870f286-687d-4187-b659-97ed33fa1517'),
(8,3,NULL,2,NULL,'benf\\neo\\elements\\Block',1,0,'2024-09-09 15:05:34','2024-09-09 15:05:37',NULL,NULL,'24448ade-d936-48ff-b41d-80165d40dd97'),
(9,4,NULL,3,NULL,'benf\\neo\\elements\\Block',1,0,'2024-09-09 15:05:34','2024-09-09 15:05:37',NULL,NULL,'efeeac56-92e4-45c7-beb1-14d05df10eeb'),
(10,5,NULL,4,NULL,'benf\\neo\\elements\\Block',1,0,'2024-09-09 15:05:34','2024-09-09 15:05:37',NULL,NULL,'6111b160-20a8-4d67-9292-64cd6284e0d9'),
(11,6,NULL,5,NULL,'benf\\neo\\elements\\Block',1,0,'2024-09-09 15:05:34','2024-09-09 15:05:37',NULL,NULL,'aa323485-ebef-4ccb-8bd6-3f6a362331ef'),
(13,2,NULL,6,1,'craft\\elements\\Entry',1,0,'2024-09-09 15:05:43','2024-09-09 15:05:43',NULL,NULL,'87c43b88-7208-43a7-aced-1de9c1ffc3d7'),
(15,2,NULL,7,1,'craft\\elements\\Entry',1,0,'2024-09-09 15:08:49','2024-09-09 15:08:49',NULL,NULL,'1f4c055e-632b-4dbb-be38-ffa41a1acd5b');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jzyxmhmtxpayubknadbqerymhbfkiuaaedpj` (`elementId`,`siteId`),
  KEY `idx_btdnscrqwrrbecfgifeeijctdezaueqqkejp` (`siteId`),
  KEY `idx_fgiqifwmdibwthqmodzlznzijfhmdgzaiflv` (`slug`,`siteId`),
  KEY `idx_evrzmijragthzimjejewvzumallusmjziwlg` (`enabled`),
  KEY `idx_dwxzxeamgmbbdfqquwxjobpikltfgehsqirz` (`uri`,`siteId`),
  CONSTRAINT `fk_lplacgsujzidnpmurneyjgodavtlhneoyufs` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_oochjnhtyjffdijqrfdeuqrtuyzdiptddzbm` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES
(1,1,1,NULL,NULL,1,'2024-09-09 14:58:08','2024-09-09 14:58:08','f4659189-9398-4875-b07b-76b811baaa24'),
(2,2,1,'test-page','page/test-page',1,'2024-09-09 15:05:25','2024-09-09 15:05:29','6bf3c536-d9d8-4dc1-8d6e-8772c4888c44'),
(3,3,1,NULL,NULL,1,'2024-09-09 15:05:29','2024-09-09 15:05:29','84376d2c-779d-4fa2-9c9d-9616e17693b9'),
(4,4,1,NULL,NULL,1,'2024-09-09 15:05:30','2024-09-09 15:05:30','dd99c051-9ebe-41c0-ba9c-06baa58dcdea'),
(5,5,1,NULL,NULL,1,'2024-09-09 15:05:32','2024-09-09 15:05:32','29ebee94-345d-41d9-980e-bc069d2659f3'),
(6,6,1,NULL,NULL,1,'2024-09-09 15:05:33','2024-09-09 15:05:33','b33e253a-4753-4356-9fdb-1f879731104f'),
(7,7,1,'test-page','page/test-page',1,'2024-09-09 15:05:37','2024-09-09 15:05:37','fa10cf33-6730-4559-b7c3-0dcaaf16a53c'),
(8,8,1,NULL,NULL,1,'2024-09-09 15:05:37','2024-09-09 15:05:37','e9ab9c80-bc68-4ed3-bc14-1c9cad23bb4d'),
(9,9,1,NULL,NULL,1,'2024-09-09 15:05:37','2024-09-09 15:05:37','8b86a4c2-22df-44af-b186-e2a0be62d1a1'),
(10,10,1,NULL,NULL,1,'2024-09-09 15:05:37','2024-09-09 15:05:37','fd3645fb-9efa-4cc6-a51e-574be5492316'),
(11,11,1,NULL,NULL,1,'2024-09-09 15:05:37','2024-09-09 15:05:37','9115dac5-077f-48bf-91b4-491c1f097ae4'),
(13,13,1,'test-page','page/test-page',1,'2024-09-09 15:05:43','2024-09-09 15:05:43','799143b3-90c3-4105-9ee4-cea493cc0605'),
(15,15,1,'test-page','page/test-page',1,'2024-09-09 15:08:49','2024-09-09 15:08:49','03ee953f-787c-4434-a7b3-1b4f5d602428');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gvoxwzlivdbzmoivorxmbmbenajfreptbmtm` (`postDate`),
  KEY `idx_mmtdruakubzoivxhtxtswbblwfrqhwgccjph` (`expiryDate`),
  KEY `idx_rqispwnzkaxqsuhdaptcqpvlwfyvbtiauspd` (`authorId`),
  KEY `idx_vcbfmalskixqbazcthzqjhjclwfjuieigdap` (`sectionId`),
  KEY `idx_veeifxrzlmoqzavyohhxwcwnbelbrpjazhze` (`typeId`),
  KEY `fk_cwlhfgvwrtwkgrqlureqtmnfcgzqebwodoad` (`parentId`),
  CONSTRAINT `fk_aqzivsniibgnfxhjovlqnvcrntryunxsdkdy` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_auwnhtmkrpcpzvuytsysusroynpihmjhptld` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cwlhfgvwrtwkgrqlureqtmnfcgzqebwodoad` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mutquotmaehtroxuzdesftrlwckwdytvnmkp` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xwebnsnuwihhekmzmzcsfjheualzjpkbkrla` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES
(2,1,NULL,1,1,'2024-09-09 15:05:00',NULL,NULL,'2024-09-09 15:05:25','2024-09-09 15:05:37'),
(7,1,NULL,1,1,'2024-09-09 15:05:00',NULL,NULL,'2024-09-09 15:05:37','2024-09-09 15:05:37'),
(13,1,NULL,1,1,'2024-09-09 15:05:00',NULL,NULL,'2024-09-09 15:05:43','2024-09-09 15:05:43'),
(15,1,NULL,1,1,'2024-09-09 15:05:00',NULL,NULL,'2024-09-09 15:08:49','2024-09-09 15:08:49');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `titleFormat` varchar(255) DEFAULT NULL,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text DEFAULT NULL,
  `showStatusField` tinyint(1) DEFAULT 1,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zhlrgjnbvnexovasmaiwsbcfjpgzqtbrbgpb` (`name`,`sectionId`),
  KEY `idx_pdoliuudvhgogzholuucqmpakbqgiqmrueno` (`handle`,`sectionId`),
  KEY `idx_zkwpgimluujpdqseosgyzvzckllgplhoetwi` (`sectionId`),
  KEY `idx_wbmtbnbcmkvxufiwcudubaxldwbkyyvwwxgc` (`fieldLayoutId`),
  KEY `idx_wixykebldocbfbtqjewozfibcxxxgcoqduzv` (`dateDeleted`),
  CONSTRAINT `fk_nwxxxpmhfwfxcggvyzscpdyzngdecghliexa` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nxwkrmsgdkejsieimfqfcwvdodqmsoxtgtmt` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES
(1,1,1,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2024-09-09 14:59:57','2024-09-09 14:59:57',NULL,'95196907-01af-461a-8bfe-5ff481befb9b');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uokfullllnzulvpensiymlgpaqldnvlyslkl` (`name`),
  KEY `idx_nrtvqefwxameldxdwmtlxvzmppgyhjifgiqz` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES
(1,'Common','2024-09-09 14:58:08','2024-09-09 14:58:08',NULL,'f4d80fe1-e5ac-46ba-8664-323c3c5627a9');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wellogzojjnhmqmkjxpfjttwonnxcubnijcq` (`layoutId`,`fieldId`),
  KEY `idx_lzkebelzdttjcfbsyjzonaevekhooedtofkd` (`sortOrder`),
  KEY `idx_vaexelccbsrhherqkglkmhpfhjlgjqodbdsv` (`tabId`),
  KEY `idx_vlzncfuyxceuagzegbeapxqskbhikgqnlndc` (`fieldId`),
  CONSTRAINT `fk_qkknwynzceegfbjzczqygqjvuwpgqerykukc` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wxxaecaflsmkocaiczohxhlispyotnepdzlg` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xenrjfqmjhierqtmizjkzlolcyxamukikmes` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `fieldlayoutfields` VALUES
(1,1,2,1,0,1,'2024-09-09 15:05:19','2024-09-09 15:05:19','675ed930-a88b-41f9-a707-23b1cbdbbb62');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bdqixzcoiksymziodghvcvjaoayuyartotap` (`dateDeleted`),
  KEY `idx_hufyqmskpgslvddldtglbahdftrltmmyfyal` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES
(1,'craft\\elements\\Entry','2024-09-09 14:59:57','2024-09-09 14:59:57',NULL,'0ec5f43c-d01f-446e-bef2-7271b7351aa4');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `elements` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jcpfzwczdnawzpvasgisotfuqgoudxkabxrk` (`sortOrder`),
  KEY `idx_aasbkabhuohbdkicqhunvixuaegbjoxiwobv` (`layoutId`),
  CONSTRAINT `fk_xyfjtxcaqtdgnprtbnglzygtcptltzhopbfr` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `fieldlayouttabs` VALUES
(2,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"659abfc9-3630-4c75-bf79-3b2542e75aa8\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"fb84c6c9-2bcc-4430-abfb-2ba934dc13e5\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"bc07ad34-dedb-4130-9d3d-80fa10e906a2\"}]',1,'2024-09-09 15:05:19','2024-09-09 15:05:19','b3a47a0e-9d6e-4108-9c52-8d54d4a545ab');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `searchable` tinyint(1) NOT NULL DEFAULT 1,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_butuzkuszcxcfrxxfspflzkyjlndmtzxzcud` (`handle`,`context`),
  KEY `idx_admqnoipkqfmtabllzgyjbgfsevyxffdrbcx` (`groupId`),
  KEY `idx_ifsmvfjuehzmgydxpjczsgudcrvcrinrxicv` (`context`),
  CONSTRAINT `fk_dfveeuuizkottthiqufmdrmgobmyyzfwpfto` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES
(1,1,'Flexible Field','flexibleField','global',NULL,NULL,0,'site',NULL,'benf\\neo\\Field','{\"maxBlocks\":null,\"maxLevels\":null,\"maxTopBlocks\":null,\"minBlocks\":null,\"minLevels\":null,\"minTopBlocks\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\"}','2024-09-09 15:05:05','2024-09-09 15:05:05','bc07ad34-dedb-4130-9d3d-80fa10e906a2');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_thmntmrjuzyeehrdtvgozlmidefnwochfyap` (`name`),
  KEY `idx_rxvrjgslpdzlkfhnebcyyimmgubnfdjmaliq` (`handle`),
  KEY `idx_szfkacjfxrzpukjqywcduhmojmtpuseqtobu` (`fieldLayoutId`),
  KEY `idx_tzgpoljfbtxhbxsoipirbjyxgopddcrkqwhp` (`sortOrder`),
  CONSTRAINT `fk_dbpauicasjlwesskjkfnxhmzjngobxvkhnhu` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_poxrlcgzfulkitvufbcygiukzgvjqluhfuxm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uebkeprofwdzdefltdpmruyxpgrvzhozqkuh` (`accessToken`),
  UNIQUE KEY `idx_sgiobkiddhzfkjhbtcqqshbknkexoqssnwke` (`name`),
  KEY `fk_drduekhjsasximflmkfsxkktrujixzdoelex` (`schemaId`),
  CONSTRAINT `fk_drduekhjsasximflmkfsxkktrujixzdoelex` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT 0,
  `inProgress` tinyint(1) NOT NULL DEFAULT 0,
  `error` tinyint(1) NOT NULL DEFAULT 0,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jflnwojuvcjhcbwrezvaksecuqvoxfzgdfnl` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT 1,
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_akvbdkwlxmsytxiphiqlarnfuwxlihucritt` (`name`),
  KEY `idx_irtoimgpmptfnweumqlvueovcbzlkeeocftj` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES
(1,'4.12.1','4.5.3.0',0,'ekwydynmkxhw','3@fxazleaucf','2024-09-09 14:58:08','2024-09-09 15:05:19','e7287e5d-9a90-4cb1-8869-eab3e99f55af');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `primaryOwnerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ktrtyoolghjepccdwyaihqejxtmsdtrgltkr` (`primaryOwnerId`),
  KEY `idx_mqmuptyowtgyqynrpwdwzgirwhkbbhoaasqs` (`fieldId`),
  KEY `idx_tjptvvyskmacolafqhoxlarvegekjynssjtu` (`typeId`),
  CONSTRAINT `fk_ctpqucsrbzagmnqehqviesxomgrnrrzhbddq` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gcbopazyrpbfizxinubqsanyovxeudytxlpl` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rbqjfyqqvjsdttljmkvgvakeudmbnvujhogw` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xmjmjiitjwrhorcbqkudfrvvlpuxwpqfxgzk` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_usacboylrruqkbxarxowouyujmcvpzazlofc` (`ownerId`),
  CONSTRAINT `fk_evmjjphoafbsmdprmxbpenqfrifuykcomqst` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_usacboylrruqkbxarxowouyujmcvpzazlofc` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mlwxafmhjmzknogbbhlaevkptgghaizgxnnt` (`name`,`fieldId`),
  KEY `idx_yjjmwyagpxbtiyrcxgrqwjsufcvydgopnvtg` (`handle`,`fieldId`),
  KEY `idx_tmendikrreluoopmgqhpahmgqlwytuupsulq` (`fieldId`),
  KEY `idx_tujgtikyyrszhicrwxhjergvwaxjvvwnhyio` (`fieldLayoutId`),
  CONSTRAINT `fk_hqjhkohifquwqodgmtllftjexefhqcnpdwuh` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kidtwspcbbstkpjaqwqtwtfmvsfjryuysngy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wtmjsbrrdqndfcawvquauiadssyaechkgxsp` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'craft','Install','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','9e8dc49d-386b-4f6d-9ac3-159ad0b993ac'),
(2,'craft','m210121_145800_asset_indexing_changes','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','fa970923-d989-4571-94cc-aacc92a9f4e3'),
(3,'craft','m210624_222934_drop_deprecated_tables','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','4ebe6a22-ab59-4bf4-92bc-de91a89489a1'),
(4,'craft','m210724_180756_rename_source_cols','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','4f3ac9a2-238f-4cc2-b139-283b00e1b550'),
(5,'craft','m210809_124211_remove_superfluous_uids','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','1416c65b-e18b-447d-928e-93d407b9574e'),
(6,'craft','m210817_014201_universal_users','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','afaddd4f-ef7b-44a0-b6c8-3c1c1723e51c'),
(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','7b31598c-5192-4d4d-b376-2e2ee02b31a9'),
(8,'craft','m211115_135500_image_transformers','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','13caa49a-0c3b-4e69-b8eb-13a2773e43d3'),
(9,'craft','m211201_131000_filesystems','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','cc11238e-e89a-4049-a2a1-1c8a8b7bd0f2'),
(10,'craft','m220103_043103_tab_conditions','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','50cc47a4-9875-4ca7-bffd-d5bbe1ffd864'),
(11,'craft','m220104_003433_asset_alt_text','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','852b733e-8bf1-4d3a-a1f8-bca7e1a5988e'),
(12,'craft','m220123_213619_update_permissions','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','6cce1b49-8d75-4b1d-afd5-5dfbff4de1e7'),
(13,'craft','m220126_003432_addresses','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','8e3448fb-35c4-4bc7-90f9-5793fc0875a8'),
(14,'craft','m220209_095604_add_indexes','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','dccd9b38-dcaf-4029-b35a-a3a123e83454'),
(15,'craft','m220213_015220_matrixblocks_owners_table','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','beec1112-0603-43d8-a496-aa6a9dc98c56'),
(16,'craft','m220214_000000_truncate_sessions','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','1d1838c1-fffd-4421-96f6-db925042e6fa'),
(17,'craft','m220222_122159_full_names','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','7851252d-960f-4d1c-8b6f-da540c64f72f'),
(18,'craft','m220223_180559_nullable_address_owner','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','cce85148-579d-486d-ae8a-7a03d2891ce7'),
(19,'craft','m220225_165000_transform_filesystems','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','b5d3ae6d-604f-42d2-8d49-86726308aee9'),
(20,'craft','m220309_152006_rename_field_layout_elements','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','d9e754e1-77a3-47c7-81a9-cb96c2ca9569'),
(21,'craft','m220314_211928_field_layout_element_uids','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','58001d6d-40ac-4204-b0af-1d79a797b8af'),
(22,'craft','m220316_123800_transform_fs_subpath','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','1ade36a0-949b-45d4-99c5-4a40f3df0a69'),
(23,'craft','m220317_174250_release_all_jobs','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','abc729d5-eecd-4af5-9c3a-05b30bc4c1a0'),
(24,'craft','m220330_150000_add_site_gql_schema_components','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','9a5d8377-b5c7-4f34-bca1-1d3ed9feb139'),
(25,'craft','m220413_024536_site_enabled_string','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','8ce7d6dc-4a02-4df8-b849-e5682a7b750a'),
(26,'craft','m221027_160703_add_image_transform_fill','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','8d5b69ce-7284-4687-8e41-de0b7a78a959'),
(27,'craft','m221028_130548_add_canonical_id_index','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','dc1f1e04-2100-41da-b220-c67785f51251'),
(28,'craft','m221118_003031_drop_element_fks','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','68ef3c46-cbdc-4415-8899-7ac692d6dae8'),
(29,'craft','m230131_120713_asset_indexing_session_new_options','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','b17d1db4-891c-40ef-bd3a-67d7d977359e'),
(30,'craft','m230226_013114_drop_plugin_license_columns','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','490090cc-b78e-4598-9c55-0ae96b8f9330'),
(31,'craft','m230531_123004_add_entry_type_show_status_field','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','a485258d-5425-4174-9d96-fc66f5fcaf44'),
(32,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','11254647-0abd-4ed2-81f3-26ef92bbcc28'),
(33,'craft','m230710_162700_element_activity','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','8a41a4c1-3ee5-4f81-869e-fa43828632f4'),
(34,'craft','m230820_162023_fix_cache_id_type','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','431ab869-dc16-48c2-b0ec-6e93f76f7350'),
(35,'craft','m230826_094050_fix_session_id_type','2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:58:08','295bca46-3f41-4d7a-b508-1ba5994e6010'),
(36,'plugin:neo','Install','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','35e0a1c1-d4d5-4130-a6c9-4a84f639bd2d'),
(37,'plugin:neo','m220409_142203_neoblocks_owners_table','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','0d370de4-3edb-4769-9746-c2747b97dbd5'),
(38,'plugin:neo','m220411_111523_remove_ownersiteid_and_uid_neoblocks_columns','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','ba670f2e-0e7f-46cd-aeec-c100e3ea27b3'),
(39,'plugin:neo','m220412_135950_neoblockstructures_rename_ownersiteid_to_siteid','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','a9e95b54-04c5-4967-9536-c963b9a46289'),
(40,'plugin:neo','m220421_105948_resave_shared_field_layouts','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','01880443-689e-4863-96fb-2ecae13a10cc'),
(41,'plugin:neo','m220428_060316_add_group_dropdown_setting','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','fb4c9686-2cd2-4b41-a41e-aa848b5e67e2'),
(42,'plugin:neo','m220511_054742_delete_converted_field_block_types_and_groups','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','05b09065-4ba7-4335-a6f0-1bd723411eba'),
(43,'plugin:neo','m220516_124013_add_blocktype_description','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','ddbe7722-b727-4db9-bd1f-c1756594ef5d'),
(44,'plugin:neo','m220723_153601_add_conditions_column_to_block_types','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','b351d114-337c-4e61-afaa-d01fb9b86468'),
(45,'plugin:neo','m220731_130608_add_min_child_blocks_column_to_block_types','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','23911599-2a50-49d5-9f97-5108b1e3f818'),
(46,'plugin:neo','m220805_072702_add_min_blocks_column_to_block_types','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','28ff75eb-faca-4d32-9b96-7ca87c58aecb'),
(47,'plugin:neo','m220805_112335_add_min_sibling_blocks_column_to_block_types','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','06754849-6f7c-4d94-83a4-d927c2850a4b'),
(48,'plugin:neo','m220812_115137_add_enabled_column_to_block_types','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','60267cca-c8e0-4e5a-8a50-05f830e93303'),
(49,'plugin:neo','m221006_052456_add_group_child_block_types_column_to_block_types','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','df26e8cb-9b49-4f6d-a63a-9c3a337c90e7'),
(50,'plugin:neo','m221110_132322_add_ignore_permissions_to_block_types','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','3e65d318-59e2-417b-a887-038419bbe7c1'),
(51,'plugin:neo','m221231_110307_add_block_type_icon_property','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','1cf81e6b-9543-401e-8abe-0b81041b5383'),
(52,'plugin:neo','m230202_000653_convert_project_config_icon_data','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','1061de33-4875-43d1-bce6-d7124094a159'),
(53,'plugin:neo','m231005_132818_add_block_type_icon_filename_property','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','dbaacd51-3b70-41b2-808f-ea1b8978e2ae'),
(54,'plugin:neo','m231027_012155_project_config_sort_orders','2024-09-09 14:59:45','2024-09-09 14:59:45','2024-09-09 14:59:45','b06ff86c-c9f6-45b3-9663-ab0e22b932a5');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neoblocks`
--

DROP TABLE IF EXISTS `neoblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neoblocks` (
  `id` int(11) NOT NULL,
  `primaryOwnerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ebjxamdvsyfshzjygqyqhwhycsyuanbmxjht` (`primaryOwnerId`),
  KEY `idx_jfvsqbuknnbnpjcyonvkvrmnzgqswggkvquf` (`fieldId`),
  KEY `idx_xhmhjyutqhxgaekblbwznkfokstnfitpxplm` (`typeId`),
  CONSTRAINT `fk_lejsowzlesdlsleyjydxapceefbiorqofatr` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qtnsksijhueqpssxdhsgohxmhifrfzvikgnc` FOREIGN KEY (`typeId`) REFERENCES `neoblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uepnjrbnywzhpruowkokdhccwiwuplobgljf` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uqvqxlbqadkckildkolemswttxeycfwewios` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neoblocks`
--

LOCK TABLES `neoblocks` WRITE;
/*!40000 ALTER TABLE `neoblocks` DISABLE KEYS */;
INSERT INTO `neoblocks` VALUES
(3,2,1,1,NULL,'2024-09-09 15:05:29','2024-09-09 15:05:29'),
(4,2,1,2,NULL,'2024-09-09 15:05:30','2024-09-09 15:05:30'),
(5,2,1,1,NULL,'2024-09-09 15:05:32','2024-09-09 15:05:32'),
(6,2,1,2,NULL,'2024-09-09 15:05:33','2024-09-09 15:05:33'),
(8,7,1,1,NULL,'2024-09-09 15:05:37','2024-09-09 15:05:37'),
(9,7,1,2,NULL,'2024-09-09 15:05:37','2024-09-09 15:05:37'),
(10,7,1,1,NULL,'2024-09-09 15:05:37','2024-09-09 15:05:37'),
(11,7,1,2,NULL,'2024-09-09 15:05:37','2024-09-09 15:05:37');
/*!40000 ALTER TABLE `neoblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neoblocks_owners`
--

DROP TABLE IF EXISTS `neoblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neoblocks_owners` (
  `blockId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_wvvcqvnfmzynjzmdtrnxdhbwghnvqgazysts` (`ownerId`),
  CONSTRAINT `fk_arpvkxbnndmkjtlevjtatqheojcmaknadvio` FOREIGN KEY (`blockId`) REFERENCES `neoblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wvvcqvnfmzynjzmdtrnxdhbwghnvqgazysts` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neoblocks_owners`
--

LOCK TABLES `neoblocks_owners` WRITE;
/*!40000 ALTER TABLE `neoblocks_owners` DISABLE KEYS */;
INSERT INTO `neoblocks_owners` VALUES
(3,2,1),
(4,2,2),
(5,2,3),
(6,2,4),
(8,7,1),
(8,13,3),
(8,15,1),
(9,7,2),
(9,13,4),
(9,15,2),
(10,7,3),
(10,13,1),
(10,15,3),
(11,7,4),
(11,13,2),
(11,15,4);
/*!40000 ALTER TABLE `neoblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neoblockstructures`
--

DROP TABLE IF EXISTS `neoblockstructures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neoblockstructures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `siteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nvvfoudilkkoavcztlekmgfyewgzzzjqpaid` (`structureId`),
  KEY `idx_jcugwfabsuovlmajgcqidngsvvoejqnngscm` (`ownerId`),
  KEY `idx_uqvmebxeckvmlzvoyburnwzwrthqxjrwayrc` (`siteId`),
  KEY `idx_tdavievasnqacjemjzagwmvjpdijqwtimfbr` (`fieldId`),
  CONSTRAINT `fk_rascyutvlhmhysntjxulyewnysxdjfrpymfj` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_slfnxidbobdkhpdwrfojmmrvtqhixvbwnzvj` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tffoslabmymaabxgwcpqyxwsawloyyeyevgb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xicathfuvotfpeqktplnkvxzvptsxnalvsgr` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neoblockstructures`
--

LOCK TABLES `neoblockstructures` WRITE;
/*!40000 ALTER TABLE `neoblockstructures` DISABLE KEYS */;
INSERT INTO `neoblockstructures` VALUES
(6,5,7,1,1,'2024-09-09 15:05:38','2024-09-09 15:05:38','b49499b5-5a0e-4bbe-8032-2e640a57168d'),
(11,9,13,1,1,'2024-09-09 15:05:43','2024-09-09 15:05:43','28f1220c-c01c-410a-ade3-f90d539cc3d3'),
(14,12,2,1,1,'2024-09-09 15:08:49','2024-09-09 15:08:49','97ea999a-e0d3-4264-b0bd-743a4f4cabf6'),
(16,13,15,1,1,'2024-09-09 15:08:49','2024-09-09 15:08:49','76f00ec9-67de-437b-92e8-26b43cba6402');
/*!40000 ALTER TABLE `neoblockstructures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neoblocktypegroups`
--

DROP TABLE IF EXISTS `neoblocktypegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neoblocktypegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `alwaysShowDropdown` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xnpzuwopxhvqfmicesfmmanztzboadalpozy` (`name`,`fieldId`),
  KEY `idx_hmckvmietlrvqfvrsfxgtymfcnckzvmtcyog` (`fieldId`),
  CONSTRAINT `fk_dqldqoijccthhmkcncgpcdimmnmgsfppfnzl` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neoblocktypegroups`
--

LOCK TABLES `neoblocktypegroups` WRITE;
/*!40000 ALTER TABLE `neoblocktypegroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `neoblocktypegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `neoblocktypes`
--

DROP TABLE IF EXISTS `neoblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `neoblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `iconFilename` varchar(255) DEFAULT NULL,
  `iconId` int(11) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `minBlocks` smallint(6) unsigned DEFAULT 0,
  `maxBlocks` smallint(6) unsigned DEFAULT NULL,
  `minSiblingBlocks` smallint(6) unsigned DEFAULT 0,
  `maxSiblingBlocks` smallint(6) unsigned DEFAULT 0,
  `minChildBlocks` smallint(6) unsigned DEFAULT 0,
  `maxChildBlocks` smallint(6) unsigned DEFAULT NULL,
  `groupChildBlockTypes` tinyint(1) NOT NULL DEFAULT 1,
  `childBlocks` text DEFAULT NULL,
  `topLevel` tinyint(1) NOT NULL DEFAULT 1,
  `ignorePermissions` tinyint(1) NOT NULL DEFAULT 1,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `conditions` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_indklvhrvssdbalropddthocgbmowyibjdgq` (`handle`,`fieldId`),
  KEY `idx_skvhtrmgmektkopmtfibpmseeoczdybjqmsk` (`name`,`fieldId`),
  KEY `idx_wywebrqdsoytgpwzzlqmvyymocwqusvtpsfd` (`fieldId`),
  KEY `idx_gjomhqjcesgahocoeaaxkzwiqhvuljmalnjq` (`fieldLayoutId`),
  KEY `idx_kedrzzgmgiwqpfodkeaeggkzfmvvufjdympw` (`groupId`),
  KEY `fk_imkswulorfculyfbfumgmxpigdlcrisdajsb` (`iconId`),
  CONSTRAINT `fk_czmjidcxkvplzwgreyxvhtplbtfxblqnmoyy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ejikvilclkkhbzxvhzyjrxlcarrycxxsurib` FOREIGN KEY (`groupId`) REFERENCES `neoblocktypegroups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_imkswulorfculyfbfumgmxpigdlcrisdajsb` FOREIGN KEY (`iconId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ldimcfckizdnpzxzcviebhnfiblbubyrmans` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `neoblocktypes`
--

LOCK TABLES `neoblocktypes` WRITE;
/*!40000 ALTER TABLE `neoblocktypes` DISABLE KEYS */;
INSERT INTO `neoblocktypes` VALUES
(1,1,NULL,NULL,'A field','aField','','',NULL,1,0,0,0,0,0,2,1,'[\"aSubfield\"]',1,1,1,'[]','2024-09-09 15:05:05','2024-09-09 15:05:05','d776a904-530b-4334-831a-f651f684801b'),
(2,1,NULL,NULL,'A subfield','aSubfield','','',NULL,1,0,0,0,0,0,0,1,NULL,0,1,2,'[]','2024-09-09 15:05:05','2024-09-09 15:05:05','2a370f08-7ebd-4eeb-a58c-f470135f1ae2');
/*!40000 ALTER TABLE `neoblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lvzkmmwdskkubuixmynjzjknvcnuflkfnkru` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES
(1,'neo','4.2.12','4.0.0','2024-09-09 14:59:44','2024-09-09 14:59:44','2024-09-09 14:59:44','66242c64-3411-4eab-bda9-96e0cabd32bb');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES
('dateModified','1725894319'),
('email.fromEmail','\"ashenke@gmail.com\"'),
('email.fromName','\"Neo bug\"'),
('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elementCondition','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.autocapitalize','true'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.autocomplete','false'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.autocorrect','true'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.class','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.disabled','false'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.elementCondition','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.id','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.inputType','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.instructions','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.label','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.max','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.min','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.name','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.orientation','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.placeholder','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.readonly','false'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.requirable','false'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.size','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.step','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.tip','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.title','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.uid','\"659abfc9-3630-4c75-bf79-3b2542e75aa8\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.userCondition','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.warning','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.0.width','100'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.elementCondition','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.fieldUid','\"bc07ad34-dedb-4130-9d3d-80fa10e906a2\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.instructions','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.label','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.required','false'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.tip','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.uid','\"fb84c6c9-2bcc-4430-abfb-2ba934dc13e5\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.userCondition','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.warning','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.elements.1.width','100'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.name','\"Content\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.uid','\"b3a47a0e-9d6e-4108-9c52-8d54d4a545ab\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.fieldLayouts.0ec5f43c-d01f-446e-bef2-7271b7351aa4.tabs.0.userCondition','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.handle','\"default\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.hasTitleField','true'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.name','\"Default\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.section','\"6d06c323-6db8-4c4b-9b07-8041f4434d27\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.showStatusField','true'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.slugTranslationKeyFormat','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.slugTranslationMethod','\"site\"'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.sortOrder','1'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.titleFormat','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.titleTranslationKeyFormat','null'),
('entryTypes.95196907-01af-461a-8bfe-5ff481befb9b.titleTranslationMethod','\"site\"'),
('fieldGroups.f4d80fe1-e5ac-46ba-8664-323c3c5627a9.name','\"Common\"'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.columnSuffix','null'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.contentColumnType','\"string\"'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.fieldGroup','\"f4d80fe1-e5ac-46ba-8664-323c3c5627a9\"'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.handle','\"flexibleField\"'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.instructions','null'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.name','\"Flexible Field\"'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.searchable','false'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.settings.maxBlocks','null'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.settings.maxLevels','null'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.settings.maxTopBlocks','null'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.settings.minBlocks','null'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.settings.minLevels','null'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.settings.minTopBlocks','null'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.settings.propagationKeyFormat','null'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.settings.propagationMethod','\"all\"'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.translationKeyFormat','null'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.translationMethod','\"site\"'),
('fields.bc07ad34-dedb-4130-9d3d-80fa10e906a2.type','\"benf\\\\neo\\\\Field\"'),
('meta.__names__.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd','\"Neo bug\"'),
('meta.__names__.2a370f08-7ebd-4eeb-a58c-f470135f1ae2','\"A subfield\"'),
('meta.__names__.6d06c323-6db8-4c4b-9b07-8041f4434d27','\"Page\"'),
('meta.__names__.95196907-01af-461a-8bfe-5ff481befb9b','\"Default\"'),
('meta.__names__.bc07ad34-dedb-4130-9d3d-80fa10e906a2','\"Flexible Field\"'),
('meta.__names__.d776a904-530b-4334-831a-f651f684801b','\"A field\"'),
('meta.__names__.dd319c01-232d-4f7b-b5b3-9902b552e7e7','\"Neo bug\"'),
('meta.__names__.f4d80fe1-e5ac-46ba-8664-323c3c5627a9','\"Common\"'),
('neo.orders.bc07ad34-dedb-4130-9d3d-80fa10e906a2.0','\"blockType:d776a904-530b-4334-831a-f651f684801b\"'),
('neo.orders.bc07ad34-dedb-4130-9d3d-80fa10e906a2.1','\"blockType:2a370f08-7ebd-4eeb-a58c-f470135f1ae2\"'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.childBlocks','null'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.conditions','null'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.description','\"\"'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.enabled','true'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.field','\"bc07ad34-dedb-4130-9d3d-80fa10e906a2\"'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.group','null'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.groupChildBlockTypes','true'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.handle','\"aSubfield\"'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.icon','null'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.iconFilename','\"\"'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.ignorePermissions','true'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.maxBlocks','0'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.maxChildBlocks','0'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.maxSiblingBlocks','0'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.minBlocks','0'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.minChildBlocks','0'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.minSiblingBlocks','0'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.name','\"A subfield\"'),
('neoBlockTypes.2a370f08-7ebd-4eeb-a58c-f470135f1ae2.topLevel','false'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.childBlocks.0','\"aSubfield\"'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.conditions','null'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.description','\"\"'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.enabled','true'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.field','\"bc07ad34-dedb-4130-9d3d-80fa10e906a2\"'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.group','null'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.groupChildBlockTypes','true'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.handle','\"aField\"'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.icon','null'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.iconFilename','\"\"'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.ignorePermissions','true'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.maxBlocks','0'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.maxChildBlocks','2'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.maxSiblingBlocks','0'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.minBlocks','0'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.minChildBlocks','0'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.minSiblingBlocks','0'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.name','\"A field\"'),
('neoBlockTypes.d776a904-530b-4334-831a-f651f684801b.topLevel','true'),
('plugins.neo.edition','\"standard\"'),
('plugins.neo.enabled','true'),
('plugins.neo.licenseKey','\"R09612HC9AK1YAWLCIO16ZKD\"'),
('plugins.neo.schemaVersion','\"4.0.0\"'),
('sections.6d06c323-6db8-4c4b-9b07-8041f4434d27.defaultPlacement','\"end\"'),
('sections.6d06c323-6db8-4c4b-9b07-8041f4434d27.enableVersioning','true'),
('sections.6d06c323-6db8-4c4b-9b07-8041f4434d27.handle','\"page\"'),
('sections.6d06c323-6db8-4c4b-9b07-8041f4434d27.name','\"Page\"'),
('sections.6d06c323-6db8-4c4b-9b07-8041f4434d27.propagationMethod','\"all\"'),
('sections.6d06c323-6db8-4c4b-9b07-8041f4434d27.siteSettings.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.enabledByDefault','true'),
('sections.6d06c323-6db8-4c4b-9b07-8041f4434d27.siteSettings.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.hasUrls','true'),
('sections.6d06c323-6db8-4c4b-9b07-8041f4434d27.siteSettings.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.template','\"page/_entry.twig\"'),
('sections.6d06c323-6db8-4c4b-9b07-8041f4434d27.siteSettings.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.uriFormat','\"page/{slug}\"'),
('sections.6d06c323-6db8-4c4b-9b07-8041f4434d27.type','\"channel\"'),
('siteGroups.dd319c01-232d-4f7b-b5b3-9902b552e7e7.name','\"Neo bug\"'),
('sites.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.baseUrl','\"$PRIMARY_SITE_URL\"'),
('sites.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.handle','\"default\"'),
('sites.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.hasUrls','true'),
('sites.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.language','\"en-US\"'),
('sites.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.name','\"Neo bug\"'),
('sites.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.primary','true'),
('sites.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.siteGroup','\"dd319c01-232d-4f7b-b5b3-9902b552e7e7\"'),
('sites.143ee5c1-3d0b-479a-9ff9-bc8a8edebecd.sortOrder','1'),
('system.edition','\"solo\"'),
('system.live','true'),
('system.name','\"Neo bug\"'),
('system.schemaVersion','\"4.5.3.0\"'),
('system.timeZone','\"America/Los_Angeles\"'),
('users.allowPublicRegistration','false'),
('users.defaultGroup','null'),
('users.photoSubpath','null'),
('users.photoVolumeUid','null'),
('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text DEFAULT NULL,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) unsigned NOT NULL DEFAULT 1024,
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT 0,
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT 0,
  `dateFailed` datetime DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jxeyatabcmdfjogfgfeuwrmupxfixoooghru` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_xoefjkwloeutgflpmedljzjksvjdxeulxmqy` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_igwyrmbciaunqpwxehvsiegsaesydymvmina` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_enejdgplxnjgnpndhvasxrsuwztmpdpvkxsd` (`sourceId`),
  KEY `idx_wukmtmyiqhogweaifdcoioqrxpcwyksrgqqv` (`targetId`),
  KEY `idx_hhpsailwnpaexdnpunyanwedttgrrcyeyxia` (`sourceSiteId`),
  CONSTRAINT `fk_ibyrtfehmvoexywovzoqdaulnqdyaiaglwnc` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_odpyeadndegblaymsddddwkuhukskwtseycg` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_sxthdbgyafgqppykaycpxhcmxuivylbdhhxp` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES
('143c6201','@craft/web/assets/conditionbuilder/dist'),
('17bb0a55','@craft/web/assets/recententries/dist'),
('1e784c0a','@craft/web/assets/updater/dist'),
('222bbe54','@craft/web/assets/iframeresizer/dist'),
('24426b62','@craft/web/assets/fieldsettings/dist'),
('2901483b','@craft/web/assets/updateswidget/dist'),
('294ab7e3','@craft/web/assets/d3/dist'),
('337f91aa','@craft/web/assets/cp/dist'),
('382289c0','@craft/web/assets/tailwindreset/dist'),
('3a04a1d7','@craft/web/assets/pluginstore/dist'),
('3f3733e2','@craft/web/assets/selectize/dist'),
('409b4bb6','@craft/web/assets/admintable/dist'),
('49b5b363','@craft/web/assets/fields/dist'),
('51150849','@craft/web/assets/garnish/dist'),
('698da960','@craft/web/assets/utilities/dist'),
('79a73f5e','@craft/web/assets/fabric/dist'),
('86ab09ff','@craft/web/assets/login/dist'),
('8771d4f6','@craft/web/assets/picturefill/dist'),
('8803244a','@craft/web/assets/timepicker/dist'),
('8cc969f6','@craft/web/assets/xregexp/dist'),
('8eadbe32','@craft/web/assets/craftsupport/dist'),
('96f41109','@benf/neo/assets/dist'),
('aa9dd4c4','@craft/web/assets/vue/dist'),
('aac5249b','@craft/web/assets/editsection/dist'),
('b1b88376','@craft/web/assets/feed/dist'),
('b52187ef','@craft/web/assets/datepickeri18n/dist'),
('bb2a0e28','@craft/web/assets/jquerypayment/dist'),
('bb79d14a','@craft/web/assets/jquerytouchevents/dist'),
('bebd0c9f','@craft/web/assets/velocity/dist'),
('c8fba5bd','@craft/web/assets/dashboard/dist'),
('d3fca6ce','@craft/web/assets/edituser/dist'),
('dc2d2732','@craft/web/assets/htmx/dist'),
('e76335f6','@craft/web/assets/jqueryui/dist'),
('ed84a5e0','@bower/jquery/dist'),
('f4e9f0c','@craft/web/assets/axios/dist'),
('f918e35d','@craft/web/assets/fileupload/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kwbfhpvddrireyseoqzestnkifkhwszxbcjx` (`canonicalId`,`num`),
  KEY `fk_cjntdaepixuraefistijgsejqusnccwossok` (`creatorId`),
  CONSTRAINT `fk_cjntdaepixuraefistijgsejqusnccwossok` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_honikxnjrrgmrjqtcfkywrmdtrdgcwdmyvmt` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES
(1,2,1,1,''),
(2,3,1,1,NULL),
(3,4,1,1,NULL),
(4,5,1,1,NULL),
(5,6,1,1,NULL),
(6,2,1,2,'Applied “Draft 1”'),
(7,2,1,3,'Applied “Draft 1”');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_oqnwoaxcsolaotinypcvghzjynezlmqgkkvr` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES
(1,'email',0,1,' ashenke gmail com '),
(1,'firstname',0,1,''),
(1,'fullname',0,1,''),
(1,'lastname',0,1,''),
(1,'slug',0,1,''),
(1,'username',0,1,' admin '),
(2,'slug',0,1,' test page '),
(2,'title',0,1,' test page '),
(3,'slug',0,1,''),
(4,'slug',0,1,''),
(5,'slug',0,1,''),
(6,'slug',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT 0,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_llqepmhxemcjxgogamwisjbaqichnaukckik` (`handle`),
  KEY `idx_jvspaublulcootvmfmcnozkiwolbnhugbdgg` (`name`),
  KEY `idx_nhjmyixwbfgyvglpnfbuyqbjizdvbpsstfwl` (`structureId`),
  KEY `idx_yneaumbslxrbsoufpnmscbxvhnrtvpnxgemd` (`dateDeleted`),
  CONSTRAINT `fk_quqyqmhoiwruuqiwtawivfoggvhcttsfyuaq` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES
(1,NULL,'Page','page','channel',1,'all','end',NULL,'2024-09-09 14:59:57','2024-09-09 14:59:57',NULL,'6d06c323-6db8-4c4b-9b07-8041f4434d27');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nxcxmdjuekkpzoljhscavwtodaossxnagmws` (`sectionId`,`siteId`),
  KEY `idx_kivmyolxxdnzrqehfkbnenjhhtigqflgvaki` (`siteId`),
  CONSTRAINT `fk_ackmehzncaxqzdcogxfrydqcmcdxvkxeaefi` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_olwkiymmbgpyedlfcyslopcknzyqudwtekab` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES
(1,1,1,1,'page/{slug}','page/_entry.twig',1,'2024-09-09 14:59:57','2024-09-09 14:59:57','44826e67-c325-4f06-a4c8-583fdaf83c6f');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nbtuvfcxgmdzgssxcjlwmdixrcrygpytqejv` (`uid`),
  KEY `idx_ifsflyvtwrfzyjntdosjnovwtugjvdalivcz` (`token`),
  KEY `idx_tlauojuxijvmvmkzwntervvbycjbvocdadmx` (`dateUpdated`),
  KEY `idx_jwtfvlvuplrswclnzemvtqusneoestmpqwxr` (`userId`),
  CONSTRAINT `fk_wjtwkvvpkopajwxjauobuvgzxtvyiukewvfw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
(1,1,'-S6ol6GjX935mJONTcTFue1J0nPyz7Sc1l9U6rbuOCSiL0jBrVMJyq_5PYjXP08n_Hj9XfW3_d7jpVcDgPSavwg_uvVw2tsujwa3','2024-09-09 14:59:17','2024-09-09 15:14:24','0c522056-76f3-4547-8c14-2f237c9f6869');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_noujeezufaabsplklytlmjuucgxygudjhdlf` (`userId`,`message`),
  CONSTRAINT `fk_qwbzxbrhdmlenxxmubqodjvwxleubvscmbnt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tqbqvktocfywwluhazcmvjexcamgrwbwvqrx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES
(1,'Neo bug','2024-09-09 14:58:08','2024-09-09 14:58:08',NULL,'dd319c01-232d-4f7b-b5b3-9902b552e7e7');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 0,
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hcvypyaoaoyqwyvwmxjwbqgixoqiewkghjjc` (`dateDeleted`),
  KEY `idx_ahxzyzudyblmsrneqqmduyedfhkhaaldmatd` (`handle`),
  KEY `idx_bxajpezlslbpbfzzasromsbccdbtgarhuzaz` (`sortOrder`),
  KEY `fk_ocumhqasqdlbofsoqfjxsvsuhmpcgmtinodn` (`groupId`),
  CONSTRAINT `fk_ocumhqasqdlbofsoqfjxsvsuhmpcgmtinodn` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES
(1,1,1,'true','Neo bug','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-09-09 14:58:08','2024-09-09 14:58:08',NULL,'143ee5c1-3d0b-479a-9ff9-bc8a8edebecd');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nkulnmeemnrvhrfgxvkmqcqnwouzpyfgkrqp` (`structureId`,`elementId`),
  KEY `idx_uanxkdvyjualvivhivfknbiqutfwyvdkdsyi` (`root`),
  KEY `idx_hrolsusflohczmqlrkdfuzewjyzvvvbjlnsw` (`lft`),
  KEY `idx_enorhglvhzyfhyfqsgxbtlubtngutqzcuohd` (`rgt`),
  KEY `idx_yuoophjyhungcrqhvhdfwrbddujwwyskwqqi` (`level`),
  KEY `idx_xounqaclpbercuipbeukiixojohezicptzth` (`elementId`),
  CONSTRAINT `fk_gwuwbegzfvahbawsmfbdyliecgkokagcywtr` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
INSERT INTO `structureelements` VALUES
(16,5,NULL,16,1,10,0,'2024-09-09 15:05:38','2024-09-09 15:05:38','3675c00f-f43f-42e5-809d-a624d4beebb5'),
(17,5,8,16,2,5,1,'2024-09-09 15:05:38','2024-09-09 15:05:38','2426627d-04e2-4130-86fc-a4a93a1d1c24'),
(18,5,9,16,3,4,2,'2024-09-09 15:05:38','2024-09-09 15:05:38','6703e3c6-88d9-4ae9-adfa-092a898ab43a'),
(19,5,10,16,6,9,1,'2024-09-09 15:05:38','2024-09-09 15:05:38','efaf7474-d22f-40b5-a88c-96deb6ef702c'),
(20,5,11,16,7,8,2,'2024-09-09 15:05:38','2024-09-09 15:05:38','bcbcc2be-6f35-457a-8812-514220c0402f'),
(36,9,NULL,36,1,10,0,'2024-09-09 15:05:43','2024-09-09 15:05:43','fbbd960d-fb1f-4b5d-a914-2067963252cd'),
(37,9,10,36,2,5,1,'2024-09-09 15:05:43','2024-09-09 15:05:43','acd09ae0-73ce-4e00-8e5b-520235a06ce2'),
(38,9,11,36,3,4,2,'2024-09-09 15:05:43','2024-09-09 15:05:43','c782d93e-2011-4e50-9187-fb69e567172a'),
(39,9,8,36,6,9,1,'2024-09-09 15:05:43','2024-09-09 15:05:43','bd36f5c8-c0f2-4ad4-942e-50d10bbcc97f'),
(40,9,9,36,7,8,2,'2024-09-09 15:05:43','2024-09-09 15:05:43','4dbce57d-25ca-4f72-9290-37192d5f20fc'),
(51,12,NULL,51,1,10,0,'2024-09-09 15:08:49','2024-09-09 15:08:49','54bbe45c-0d8c-4897-8b23-9fdf7cecb5c1'),
(52,12,3,51,2,5,1,'2024-09-09 15:08:49','2024-09-09 15:08:49','2afdcc90-9b31-4493-bcc6-2f4ecf89ca29'),
(53,12,4,51,3,4,2,'2024-09-09 15:08:49','2024-09-09 15:08:49','e9f9312c-2e04-4a37-a348-fb4dbc0b7e52'),
(54,12,5,51,6,9,1,'2024-09-09 15:08:49','2024-09-09 15:08:49','9dad6135-0085-4db7-8377-10c61382d83a'),
(55,12,6,51,7,8,2,'2024-09-09 15:08:49','2024-09-09 15:08:49','7790603e-13b7-4bb5-910b-8a46bbd0f637'),
(56,13,NULL,56,1,10,0,'2024-09-09 15:08:49','2024-09-09 15:08:49','91c28fd7-92fe-4384-b5e6-189dc9d26727'),
(57,13,8,56,2,5,1,'2024-09-09 15:08:49','2024-09-09 15:08:49','80f49e2f-fba7-4a4c-bbdc-a452a5dbced8'),
(58,13,9,56,3,4,2,'2024-09-09 15:08:49','2024-09-09 15:08:49','771e3552-2e80-49de-9c35-e47c6f491fe6'),
(59,13,10,56,6,9,1,'2024-09-09 15:08:49','2024-09-09 15:08:49','e7d29288-92d9-411d-820d-b51de4e77f73'),
(60,13,11,56,7,8,2,'2024-09-09 15:08:49','2024-09-09 15:08:49','c9ed77d1-5d3b-4cbd-806a-173af8157b80');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_llwbybiklbzmxndaysvcbwavsycegxfdkoeh` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES
(5,NULL,'2024-09-09 15:05:38','2024-09-09 15:05:38','2024-09-09 15:05:38','6f2de741-9ce5-4e14-ba6f-9486791ab2f0'),
(9,NULL,'2024-09-09 15:05:43','2024-09-09 15:05:43','2024-09-09 15:05:43','c27bb633-e0e4-4d12-b2b3-dd7dc9c0630b'),
(12,NULL,'2024-09-09 15:08:49','2024-09-09 15:08:49',NULL,'f2c2ae89-b354-43f5-ba5d-061ecde79790'),
(13,NULL,'2024-09-09 15:08:49','2024-09-09 15:08:49','2024-09-09 15:08:49','b62a02e0-1663-4738-8d54-19ff7a42ba05');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dozpmdcmctmzpdjwgvckmpjiaynvksqoliqn` (`key`,`language`),
  KEY `idx_gsoiwebyzwebbjclrqhwdobfanlhjtplrtrc` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oyskmhqdpffxxbpfhhgdcjkrdskdlsakubmu` (`name`),
  KEY `idx_dlcdgvscbhuodroaeoxeapxkiqkguzcakqex` (`handle`),
  KEY `idx_ooqgndkkiokxksovqzvcvaccmglkhedxrmip` (`dateDeleted`),
  KEY `fk_hfupvfbnudetphsbzidjxjodzmixoitlxoyi` (`fieldLayoutId`),
  CONSTRAINT `fk_hfupvfbnudetphsbzidjxjodzmixoitlxoyi` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ryjnvbfqdmxtbnuqcjpntakycptlwcizdsfs` (`groupId`),
  CONSTRAINT `fk_fxukstambopbipyenqurkbfbcfhcdqlxndsz` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nixigpigccexnacmyivvyitnzgcqkaucoros` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text DEFAULT NULL,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_moorvgorqwfukexqepciqumachezdlgmitlm` (`token`),
  KEY `idx_ecnfjwlnhsduspfbhsghbqxildchxbmbpbzs` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_psqqibbkzdmmdlavuhxzomcomdigcctpygid` (`handle`),
  KEY `idx_sldnagponymnlvcwxkxucyguulmqpswwagdd` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rskdwjvrwrltkzlnrsunxwyiixwrsclekbmi` (`groupId`,`userId`),
  KEY `idx_hgzsrqeaqzxugqthtahncbdjuunhhdsehfyz` (`userId`),
  CONSTRAINT `fk_gyjrpyfxvreiexfozgftudltjiekeshewgzo` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sassmnnslmhojrbtbtvxqeuggkjtorgrylcb` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rieiihecdonzelasxafkmnxmdsqhqiwbpjtz` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lkhyggxmwhwibuluemgkhxggbacmmwolxddj` (`permissionId`,`groupId`),
  KEY `idx_tmjbtzsimzbafdbxukkdobpgagbhngigdbha` (`groupId`),
  CONSTRAINT `fk_iwzlycpnqxuuucxgflqiubgtwuuhakyqrqdl` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wqntqdlabxvikctgvhtxirgiodqfvaduunkb` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nxjolywtxrvepzroyxokiuknlsjhanuewifz` (`permissionId`,`userId`),
  KEY `idx_ktwahtkwfhwdfhaszlpkiifpisgxsuswshzv` (`userId`),
  CONSTRAINT `fk_ggdmrkdkwiswlnwagtkifmaehfzrlzfhdhia` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_obyngvzafkteonpsgafucedcidhxmvvzetla` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_ptduzzghefvwyyyagedetwuhvncuxyaicshv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES
(1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `pending` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `suspended` tinyint(1) NOT NULL DEFAULT 0,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT 0,
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT 0,
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xfekhzkpiabukkykdehbikfttjpupgemhagj` (`active`),
  KEY `idx_nicdwsjbbkccfxfkwkqizklwdaxcdxryxpwy` (`locked`),
  KEY `idx_owkkvichxmeaowjlpruepkoskigxyjmppinx` (`pending`),
  KEY `idx_rscwwobrfugexpqknrwtbwqroyxjzrvbpavo` (`suspended`),
  KEY `idx_lbitnuvcuhqgstltagxtolcmovkzackjaqzn` (`verificationCode`),
  KEY `idx_ombyjwpvpirmrxzqtafhtediklvnlpmjjdlc` (`email`),
  KEY `idx_xazjqlabecsiaixotooiwhiybqdlrdsznrzg` (`username`),
  KEY `fk_oucdacjkozchtscxgrcdeewlfxnbbgnudeup` (`photoId`),
  CONSTRAINT `fk_guxnyrhxzozjycezsjyawjigdjqwevdkvnre` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oucdacjkozchtscxgrcdeewlfxnbbgnudeup` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'ashenke@gmail.com','$2y$13$RxABW03H3dm/EqvA/1v4ue75dC9M7Lgi.EGf2bcYQGNAx.3UNYR0K','2024-09-09 14:59:17',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-09-09 14:58:08','2024-09-09 14:58:08','2024-09-09 14:59:17');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wdjszmywukfmyjjzzpddcxvynrxgrozpewyh` (`name`,`parentId`,`volumeId`),
  KEY `idx_iatojuydmnndmcpxdsgckmpwzqultwjnynmq` (`parentId`),
  KEY `idx_gozpunuuqjnxxlmpcmjqozmgkxnpjrghhchi` (`volumeId`),
  CONSTRAINT `fk_bpeysxvksxbzbmbjpinnxyayovwtkhptxhzz` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vqssddpvkyhrasuiwwrkfzcvvygcjevghtmr` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mmthxmidgbljdhwbppeeshflxsvwvvvfbrwe` (`name`),
  KEY `idx_bqeuogtsrmrqoczlflymdjuxdfjkkdljourg` (`handle`),
  KEY `idx_rntmgazwvrtbpwvfvijbmbwiicwzwwxehviv` (`fieldLayoutId`),
  KEY `idx_vzfmwarllxyyzrecbgsxrqedofxhkgemttfw` (`dateDeleted`),
  CONSTRAINT `fk_crgixgpqsawxasrnpapxiyvnbvwlydkhqmac` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jlcnttqruxqcumyihvfncfsrudmbnnxzdwwr` (`userId`),
  CONSTRAINT `fk_btxcyjuxbujagokmdynlrhalixwcludzzuew` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES
(1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2024-09-09 14:59:17','2024-09-09 14:59:17','8eb9b750-31b2-490f-93b4-98cb2d163cea'),
(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-09-09 14:59:17','2024-09-09 14:59:17','1a5c720a-baac-4cd3-b275-4f673c256af7'),
(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-09-09 14:59:17','2024-09-09 14:59:17','c6404ed8-1be0-4e2e-be93-090987ac14d2'),
(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2024-09-09 14:59:17','2024-09-09 14:59:17','d0833c6a-f9c8-49dc-9bfc-6cd15d0b93b7');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-09 15:14:39
